package View;

import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Janela única da aplicação. Cada "tela" é um JPanel colocado dentro dela.
 * As telas recebem a TelaPrincipal no construtor e usam mostrarInicial() /
 * mostrarProdutos() para navegar entre si.
 */
public class TelaPrincipal extends JFrame {

    public TelaPrincipal() {
        setTitle("Gerenciamento de Estoque");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());

        mostrarInicial();   // primeira tela ao abrir o programa
    }

    /** Troca o conteúdo da janela por qualquer JPanel. */
    public void trocarTela(JPanel tela) {
        Container conteudo = getContentPane();
        conteudo.removeAll();
        conteudo.add(tela, BorderLayout.CENTER);
        conteudo.revalidate();
        conteudo.repaint();
        pack();                      // ajusta a janela ao tamanho da nova tela
        setLocationRelativeTo(null); // centraliza
    }

    /** Mostra a tela inicial (menu). */
    public void mostrarInicial() {
        trocarTela(new TelaInicial(this));
    }

    /** Mostra a tela de gerenciamento de produtos. */
    public void mostrarProdutos() {
        trocarTela(new Produtos(this));
    }

    /** Mostra a tela com as vendas registradas e seus detalhes. */
    public void mostrarVendas() {
        trocarTela(new Vendas(this));
    }

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName())
                    .log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new TelaPrincipal().setVisible(true));
    }
}
