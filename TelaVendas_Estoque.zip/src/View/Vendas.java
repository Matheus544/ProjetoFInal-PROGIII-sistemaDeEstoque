package View;

import Controller.controllerVendas;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Tela com as vendas registradas e os detalhes da venda selecionada.
 * Feita em código (sem o editor visual do NetBeans); é um JPanel que a
 * TelaPrincipal coloca na janela, como a tela de Produtos.
 */
public class Vendas extends JPanel {

    private final TelaPrincipal principal;   // janela que troca as telas

    private final JTextField jTextFieldDe = new JTextField(9);
    private final JTextField jTextFieldAte = new JTextField(9);
    private final JButton jButtonFiltrar = new JButton("Filtrar");
    private final JButton jButtonLimparFiltro = new JButton("Limpar filtro");
    private final JButton jButtonAtualizar = new JButton("Atualizar");

    private final JTable jTableVendas = new JTable();
    private final JTable jTableItens = new JTable();

    private final JLabel jLabelDetalheTitulo = new JLabel(" ");
    private final JLabel jLabelDetalheTotal = new JLabel(" ");
    private final JLabel jLabelResumo = new JLabel(" ");
    private final JButton jButtonVoltar = new JButton("Voltar");

    private final controllerVendas c;

    public Vendas(TelaPrincipal principal) {
        this.principal = principal;
        montarTela();
        c = new controllerVendas(jTextFieldDe, jTextFieldAte, jTableVendas, jTableItens,
                jLabelResumo, jLabelDetalheTitulo, jLabelDetalheTotal);
        ajustarTabelas();   // depois do controller, que é quem cria as colunas
        ligarEventos();
    }

    private void montarTela() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        // ---- topo: período e botões
        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filtro.setBorder(BorderFactory.createTitledBorder("Período (dd/mm/aaaa — deixe em branco para todas)"));
        filtro.add(new JLabel("De:"));
        filtro.add(jTextFieldDe);
        filtro.add(new JLabel("até:"));
        filtro.add(jTextFieldAte);
        filtro.add(jButtonFiltrar);
        filtro.add(jButtonLimparFiltro);
        filtro.add(jButtonAtualizar);
        add(filtro, BorderLayout.NORTH);

        // ---- centro: vendas (em cima) e detalhes (embaixo)
        JScrollPane rolagemVendas = new JScrollPane(jTableVendas);
        rolagemVendas.setBorder(BorderFactory.createTitledBorder("Vendas"));
        rolagemVendas.setPreferredSize(new Dimension(780, 230));

        jLabelDetalheTitulo.setFont(jLabelDetalheTitulo.getFont().deriveFont(Font.BOLD));
        jLabelDetalheTotal.setFont(jLabelDetalheTotal.getFont().deriveFont(Font.BOLD, 18f));
        jLabelDetalheTotal.setHorizontalAlignment(SwingConstants.RIGHT);

        JPanel detalhe = new JPanel(new BorderLayout(0, 6));
        detalhe.setBorder(BorderFactory.createTitledBorder("Detalhes da venda"));
        detalhe.add(jLabelDetalheTitulo, BorderLayout.NORTH);
        detalhe.add(new JScrollPane(jTableItens), BorderLayout.CENTER);
        detalhe.add(jLabelDetalheTotal, BorderLayout.SOUTH);
        detalhe.setPreferredSize(new Dimension(780, 250));

        JSplitPane divisao = new JSplitPane(JSplitPane.VERTICAL_SPLIT, rolagemVendas, detalhe);
        divisao.setResizeWeight(0.5);
        add(divisao, BorderLayout.CENTER);

        // ---- rodapé: resumo e Voltar
        jLabelResumo.setFont(jLabelResumo.getFont().deriveFont(Font.BOLD, 14f));
        JPanel rodape = new JPanel(new BorderLayout());
        rodape.add(jLabelResumo, BorderLayout.WEST);
        rodape.add(jButtonVoltar, BorderLayout.EAST);
        add(rodape, BorderLayout.SOUTH);
    }

    private void ajustarTabelas() {
        for (JTable tabela : new JTable[]{jTableVendas, jTableItens}) {
            tabela.setRowHeight(24);
            tabela.setFillsViewportHeight(true);
            tabela.getTableHeader().setReorderingAllowed(false);
        }

        DefaultTableCellRenderer direita = new DefaultTableCellRenderer();
        direita.setHorizontalAlignment(SwingConstants.RIGHT);

        // vendas: Nº | Data | Hora | Total
        jTableVendas.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTableVendas.getColumnModel().getColumn(1).setPreferredWidth(120);
        jTableVendas.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTableVendas.getColumnModel().getColumn(3).setPreferredWidth(160);
        jTableVendas.getColumnModel().getColumn(0).setCellRenderer(direita);
        jTableVendas.getColumnModel().getColumn(3).setCellRenderer(direita);

        // itens: Produto | Qtd | Valor unit. | Subtotal
        jTableItens.getColumnModel().getColumn(0).setPreferredWidth(320);
        jTableItens.getColumnModel().getColumn(1).setPreferredWidth(60);
        jTableItens.getColumnModel().getColumn(2).setPreferredWidth(120);
        jTableItens.getColumnModel().getColumn(3).setPreferredWidth(120);
        for (int coluna = 1; coluna <= 3; coluna++) {
            jTableItens.getColumnModel().getColumn(coluna).setCellRenderer(direita);
        }
    }

    private void ligarEventos() {
        jButtonFiltrar.addActionListener(e -> c.filtrar());
        jTextFieldDe.addActionListener(e -> c.filtrar());    // Enter nos campos de data
        jTextFieldAte.addActionListener(e -> c.filtrar());
        jButtonLimparFiltro.addActionListener(e -> c.limparFiltro());
        jButtonAtualizar.addActionListener(e -> c.atualizar());
        jButtonVoltar.addActionListener(e -> principal.mostrarInicial());
    }
}
