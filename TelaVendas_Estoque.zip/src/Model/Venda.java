package Model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Cabeçalho de uma venda registrada (somente leitura).
 */
public class Venda {

    private final int id;
    private final LocalDateTime dataHora;
    private final BigDecimal total;

    public Venda(int id, LocalDateTime dataHora, BigDecimal total) {
        this.id = id;
        this.dataHora = dataHora;
        this.total = total;
    }

    public int getId() { return id; }
    public LocalDateTime getDataHora() { return dataHora; }
    public BigDecimal getTotal() { return total; }
}
