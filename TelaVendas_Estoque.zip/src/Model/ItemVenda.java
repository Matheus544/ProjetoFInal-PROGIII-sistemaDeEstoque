package Model;

import java.math.BigDecimal;

/**
 * Uma linha da venda: nome e preço exatamente como foram na hora da venda.
 */
public class ItemVenda {

    private final int idProduto;
    private final String nomeProduto;
    private final int quantidade;
    private final BigDecimal valorUnitario;
    private final BigDecimal subtotal;

    public ItemVenda(int idProduto, String nomeProduto, int quantidade,
            BigDecimal valorUnitario, BigDecimal subtotal) {
        this.idProduto = idProduto;
        this.nomeProduto = nomeProduto;
        this.quantidade = quantidade;
        this.valorUnitario = valorUnitario;
        this.subtotal = subtotal;
    }

    public int getIdProduto() { return idProduto; }
    public String getNomeProduto() { return nomeProduto; }
    public int getQuantidade() { return quantidade; }
    public BigDecimal getValorUnitario() { return valorUnitario; }
    public BigDecimal getSubtotal() { return subtotal; }
}
