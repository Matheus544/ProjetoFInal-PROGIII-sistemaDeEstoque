package DAO;

import Model.ItemVenda;
import Model.Venda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Consulta das vendas registradas pela aplicação de vendas.
 */
public class VendaDAO {

    /**
     * Vendas do período, da mais recente para a mais antiga.
     * "de" e "ate" são opcionais (null = sem limite); o dia "ate" entra por inteiro.
     */
    public List<Venda> listar(LocalDate de, LocalDate ate) throws SQLException {
        // o SQL só é montado com trechos fixos; os valores entram sempre por "?"
        StringBuilder sql = new StringBuilder("SELECT id, data_hora, total FROM venda");
        List<Object> parametros = new ArrayList<>();

        if (de != null) {
            sql.append(" WHERE data_hora >= ?");
            parametros.add(de.atStartOfDay());
        }
        if (ate != null) {
            sql.append(de == null ? " WHERE" : " AND").append(" data_hora < ?");
            parametros.add(ate.plusDays(1).atStartOfDay());
        }
        sql.append(" ORDER BY data_hora DESC, id DESC");

        List<Venda> lista = new ArrayList<>();
        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Venda(
                            rs.getInt("id"),
                            rs.getObject("data_hora", LocalDateTime.class),
                            rs.getBigDecimal("total")));
                }
            }
        }
        return lista;
    }

    /** Itens de uma venda, na ordem em que foram registrados. */
    public List<ItemVenda> listarItens(int idVenda) throws SQLException {
        String sql = "SELECT id_produto, nome_produto, quantidade, valor_unitario, subtotal "
                   + "FROM item_venda WHERE id_venda = ? ORDER BY id";
        List<ItemVenda> lista = new ArrayList<>();

        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idVenda);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new ItemVenda(
                            rs.getInt("id_produto"),
                            rs.getString("nome_produto"),
                            rs.getInt("quantidade"),
                            rs.getBigDecimal("valor_unitario"),
                            rs.getBigDecimal("subtotal")));
                }
            }
        }
        return lista;
    }
}
