package Controller;

import DAO.VendaDAO;
import Model.ItemVenda;
import Model.Venda;
import Util.Formatador;
import java.awt.Window;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

/**
 * Tela de vendas do estoque: lista as vendas e mostra os detalhes da selecionada.
 */
public class controllerVendas {

    private static final DateTimeFormatter FORMATO_DATA =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    private final JTextField jTextFieldDe, jTextFieldAte;
    private final JTable jTableVendas, jTableItens;
    private final JLabel jLabelResumo, jLabelDetalheTitulo, jLabelDetalheTotal;

    private final DefaultTableModel modeloVendas = new DefaultTableModel(
            new String[]{"Nº", "Data", "Hora", "Total"}, 0) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    };

    private final DefaultTableModel modeloItens = new DefaultTableModel(
            new String[]{"Produto", "Qtd", "Valor unit.", "Subtotal"}, 0) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    };

    private final VendaDAO dao = new VendaDAO();

    private List<Venda> vendas = new ArrayList<>();   // a mesma ordem das linhas da tabela
    private LocalDate filtroDe = null;                // filtro em uso (null = sem limite)
    private LocalDate filtroAte = null;

    public controllerVendas(JTextField jTextFieldDe, JTextField jTextFieldAte,
            JTable jTableVendas, JTable jTableItens,
            JLabel jLabelResumo, JLabel jLabelDetalheTitulo, JLabel jLabelDetalheTotal) {

        this.jTextFieldDe = jTextFieldDe;
        this.jTextFieldAte = jTextFieldAte;
        this.jTableVendas = jTableVendas;
        this.jTableItens = jTableItens;
        this.jLabelResumo = jLabelResumo;
        this.jLabelDetalheTitulo = jLabelDetalheTitulo;
        this.jLabelDetalheTotal = jLabelDetalheTotal;

        this.jTableVendas.setModel(modeloVendas);
        this.jTableItens.setModel(modeloItens);
        this.jTableVendas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // ao clicar em uma venda, mostra os itens dela
        this.jTableVendas.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarDetalhes();
            }
        });

        carregar();
    }

    /** Aplica o período digitado (campos vazios = sem limite) e recarrega. */
    public void filtrar() {
        LocalDate de;
        LocalDate ate;
        try {
            de = lerData(jTextFieldDe);
            ate = lerData(jTextFieldAte);
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(janela(),
                    "Data inválida. Use o formato dd/mm/aaaa (ex.: 25/12/2026).",
                    "Período", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (de != null && ate != null && de.isAfter(ate)) {
            JOptionPane.showMessageDialog(janela(),
                    "A data inicial não pode ser depois da data final.",
                    "Período", JOptionPane.WARNING_MESSAGE);
            return;
        }
        filtroDe = de;
        filtroAte = ate;
        carregar();
    }

    /** Remove o filtro e mostra todas as vendas. */
    public void limparFiltro() {
        jTextFieldDe.setText("");
        jTextFieldAte.setText("");
        filtroDe = null;
        filtroAte = null;
        carregar();
    }

    /** Recarrega do banco mantendo o filtro atual (útil para ver vendas feitas agora). */
    public void atualizar() {
        carregar();
    }

    // ---------------------------------------------------------------- apoio

    private void carregar() {
        int idSelecionado = idSelecionado();

        try {
            vendas = dao.listar(filtroDe, filtroAte);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(janela(),
                    "Erro ao carregar as vendas: " + e.getMessage()
                    + "\nConfira se o script vendas.sql foi executado no banco.",
                    "Erro de banco", JOptionPane.ERROR_MESSAGE);
            return;
        }

        modeloVendas.setRowCount(0);
        BigDecimal soma = BigDecimal.ZERO.setScale(2);
        int linhaAnterior = -1;

        for (int i = 0; i < vendas.size(); i++) {
            Venda v = vendas.get(i);
            modeloVendas.addRow(new Object[]{
                v.getId(),
                Formatador.data(v.getDataHora()),
                Formatador.hora(v.getDataHora()),
                Formatador.moeda(v.getTotal())
            });
            soma = soma.add(v.getTotal());
            if (v.getId() == idSelecionado) {
                linhaAnterior = i;
            }
        }

        jLabelResumo.setText(vendas.size() + (vendas.size() == 1 ? " venda" : " vendas")
                + "  —  Total: " + Formatador.moeda(soma));

        if (linhaAnterior >= 0) {
            jTableVendas.setRowSelectionInterval(linhaAnterior, linhaAnterior); // mantém a venda aberta
        } else {
            limparDetalhes();
        }
    }

    private void mostrarDetalhes() {
        int linha = jTableVendas.getSelectedRow();
        if (linha < 0 || linha >= vendas.size()) {
            limparDetalhes();
            return;
        }

        Venda venda = vendas.get(linha);
        List<ItemVenda> itens;
        try {
            itens = dao.listarItens(venda.getId());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(janela(),
                    "Erro ao carregar os itens da venda: " + e.getMessage(),
                    "Erro de banco", JOptionPane.ERROR_MESSAGE);
            return;
        }

        modeloItens.setRowCount(0);
        for (ItemVenda item : itens) {
            modeloItens.addRow(new Object[]{
                item.getNomeProduto(),
                item.getQuantidade(),
                Formatador.moeda(item.getValorUnitario()),
                Formatador.moeda(item.getSubtotal())
            });
        }

        jLabelDetalheTitulo.setText("Venda nº " + venda.getId()
                + "  —  " + Formatador.data(venda.getDataHora())
                + " às " + Formatador.hora(venda.getDataHora())
                + "  —  " + itens.size() + (itens.size() == 1 ? " produto" : " produtos"));
        jLabelDetalheTotal.setText("Total da venda: " + Formatador.moeda(venda.getTotal()));
    }

    private void limparDetalhes() {
        modeloItens.setRowCount(0);
        jLabelDetalheTitulo.setText("Selecione uma venda para ver os detalhes.");
        jLabelDetalheTotal.setText(" ");
    }

    private int idSelecionado() {
        int linha = jTableVendas.getSelectedRow();
        return (linha >= 0 && linha < vendas.size()) ? vendas.get(linha).getId() : -1;
    }

    /** Campo vazio = null (sem limite). Data inexistente (31/02) também é recusada. */
    private LocalDate lerData(JTextField campo) {
        String texto = campo.getText().trim();
        return texto.isEmpty() ? null : LocalDate.parse(texto, FORMATO_DATA);
    }

    private Window janela() {
        return SwingUtilities.getWindowAncestor(jTableVendas);
    }
}
