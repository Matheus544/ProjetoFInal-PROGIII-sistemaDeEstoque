/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Produto;
import java.awt.List;
import java.math.BigDecimal;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;

/**
 *
 * @author Discentes
 */
public class controllerProduto {
    JTextField jTextFieldCodbarra, jTextFieldNome, jTextFieldPreco, jTextFieldValor, jTextFieldFornecedor, jTextFieldQuantidade, jTextFieldMarca;
    
    JList jListProdutos;
    
    DefaultListModel<Produto> modelo = new DefaultListModel<>();
    
    

    public controllerProduto(JTextField jTextFieldCodbarra, JTextField jTextFieldNome, JTextField jTextAreaPreco, JTextField jTextAreaValor, JTextField jTextFieldFornecedor, JTextField jTextFieldQuantidade, JTextField jTextFieldMarca, JList jListProdutos){
        this.jTextFieldCodbarra = jTextFieldCodbarra;
        this.jTextFieldNome = jTextFieldNome;
        this.jTextFieldPreco = jTextAreaPreco;
        this.jTextFieldValor = jTextAreaValor;
        this.jTextFieldFornecedor = jTextFieldFornecedor;
        this.jTextFieldQuantidade = jTextFieldQuantidade;
        this.jTextFieldMarca = jTextFieldMarca;
        this.jListProdutos = jListProdutos;
        
    }
    
    
   
    public void salvar(){
        String codBarra = jTextFieldCodbarra.getText();
        String nome = jTextFieldNome.getText();
        BigDecimal preco = new BigDecimal(jTextFieldPreco.getText());
        BigDecimal valor = new BigDecimal(jTextFieldValor.getText());
        String fornecedor = jTextFieldFornecedor.getText();
        int quantidade = Integer.parseInt(jTextFieldQuantidade.getText());
        String marca = jTextFieldMarca.getText();
        
        Produto produto = new Produto (
                codBarra,
                nome,
                preco,
                valor,
                fornecedor,
                marca,
                quantidade

        );
        modelo.addElement(produto);
        limpar();
        
    }
    public void limpar() {
        jTextFieldCodbarra.setText("");
        jTextFieldNome.setText("");
        jTextFieldPreco.setText("");
        jTextFieldValor.setText("");
        jTextFieldMarca.setText("");
        jTextFieldQuantidade.setText("");
        jTextFieldFornecedor.setText("");
    }
            
}
